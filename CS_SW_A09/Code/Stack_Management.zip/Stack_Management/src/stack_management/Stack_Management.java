/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stack_management;

import java.sql.*;
import java.util.Scanner;
import java.time.*;

/**
 *
 * @author Mohammad Nasir Ariae
 */
public class Stack_Management {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/Stack_Management";
        Scanner INT = new Scanner(System.in);
        Scanner STR = new Scanner(System.in);
        try { 
            Connection con = DriverManager.getConnection(url, "root", "");
            PreparedStatement NewOwner = con.prepareStatement("INSERT INTO owner VALUES(?,?,?,?)");
            System.out.println("connectoin established:");
            PreparedStatement NewMaterials = con.prepareStatement("INSERT INTO materials VALUES (?,?,?,?,?,?,?)");
            PreparedStatement StackInfo = con.prepareStatement("INSERT INTO stack VALUES (?,?)");
            PreparedStatement OwnerTable = con.prepareStatement("SELECT *FROM owner");
            PreparedStatement MaterialsTable = con.prepareStatement("SELECT *FROM materials");
            PreparedStatement StackTable = con.prepareStatement("SELECT *FROM stack");
            Statement OwnerDel = con.createStatement();
            Statement MatDel = con.createStatement();
            Statement StackDel = con.createStatement();
            Statement Stack = con.createStatement();
            while (true) {

                System.out.println("Select what do you want to do: 1 for insertion,2 for seeing data 3 for Updation and deletion and 4 for exit:");
                int choice;
                choice = INT.nextInt();
                switch (choice) {
                    case 1:

                        System.out.println("Input: 1 for MaterialOwner 2 for Materials 3 for Stack_info");
                        int ch;
                        ch = INT.nextInt();
                        switch (ch) {
                            case 1:
                                System.out.println("Enter Owner ID: ");
                                NewOwner.setInt(1, INT.nextInt());
                                System.out.println("Entr Owner Name: ");
                                NewOwner.setString(2, STR.nextLine());
                                System.out.println("Enter Owner Address: ");
                                NewOwner.setString(3, STR.nextLine());
                                System.out.println("Enter Contact No Of Owner: ");
                                NewOwner.setInt(4, INT.nextInt());
                                System.out.println("Number of records affected: " + NewOwner.executeUpdate());
                                break;
                            case 2:
                                System.out.println("Enter the name of materials: ");
                                NewMaterials.setString(1, STR.nextLine());
                                System.out.println("Enter the Amount of Materials: ");
                                NewMaterials.setString(2, STR.nextLine());
                                System.out.println("Enter The days of Materials: ");
                                int day = INT.nextInt();
                                NewMaterials.setInt(3, day);
                                System.out.println("Enter The price/day of materials: ");
                                int perDay = INT.nextInt();
                                NewMaterials.setInt(4, perDay);
                                //System.out.println("Enter the total price of Materials");
                                day *= perDay;
                                NewMaterials.setInt(5, day);
                                System.out.println("Enter Stack Name: ");
                                NewMaterials.setString(6, STR.nextLine());
                                System.out.println("Enter Owner ID: ");
                                NewMaterials.setInt(7, INT.nextInt());
                                System.out.println("Number of records affected: " + NewMaterials.executeUpdate());
                                break;
                            case 3:
                                System.out.println("Enter a name for stack:");
                                StackInfo.setString(1, STR.nextLine());
                                System.out.println("Enter an Address for Stack:");
                                StackInfo.setString(2, STR.nextLine());
                                System.out.println("Information has setted:" + StackInfo.executeUpdate());
                                break;

                        }
                        break;
                    case 2:
                        System.out.println("Which table data do you want to see(Owner,Materials or Stack)");
                        String chooseTable = STR.nextLine();
                        if (chooseTable.equals("Owner")) {
                            ResultSet RSet = OwnerTable.executeQuery();
                            System.out.println("List of all Material's owners:");
                            System.out.println("ID   \tName     \tAddress   \tContact");
                            while (RSet.next()) {
                                System.out.println(RSet.getInt("O_ID") + "   \t" + RSet.getString("O_Name") + "      \t" + RSet.getString("O_Address") + "   \t" + RSet.getInt("O_Contact"));

                            }
                        } else if (chooseTable.equals("Materials")) {
                            ResultSet Mset = MaterialsTable.executeQuery();
                            System.out.println("List all Materials of Stack:");
                            System.out.println("Ma_Name\t        Ma_Amount\t Ma_Days\t Ma_Pric/Day\t Ma_TotalPrice\t   StackName\t     Owner_ID");
                            while (Mset.next()) {
                                System.out.println(Mset.getString("m_name") + "   \t   " + Mset.getInt("amount") + "     \t   " + Mset.getInt("days") + "      \t   " + Mset.getInt("price_day") + "    \t   " + Mset.getInt("total_price") + "     \t   " + Mset.getString("s_name") + "    \t" + Mset.getInt("o_id"));
                            }

                        } else if (chooseTable.equals("Stack")) {
                            ResultSet StackSet = StackTable.executeQuery();
                            System.out.println("Stack_Name     \t        Stack_Address");
                            while (StackSet.next()) {
                                System.out.println(StackSet.getString("Name") + "\t        " + StackSet.getString("Address"));
                            }
                        }
                        break;
                    case 3:
                        System.out.println("What do you do Deletion or Updation:");
                        String DeUp = STR.nextLine();
                        if (DeUp.equals("Deletion")) {
                            System.out.println("Which table do you want delete records from(Owner,Materials,Stack)");
                            String chTable = STR.nextLine();
                            if (chTable.equals("Owner")) {
                                System.out.println("Which name do you want to delete:");
                                String Del = STR.nextLine();
                                OwnerDel.executeUpdate("DELETE FROM owner WHERE O_Name = '" + Del + "'");

                            } else if (chTable.equals("Materials")) {
                                System.out.println("Which base do you want to delete items Owner ID base or Material Name base:");
                                String base = STR.nextLine();
                                if (base.equals("ID")) {
                                    System.out.println("Which Material do you want to delete type the ID:");
                                    int id = INT.nextInt();
                                    MatDel.executeUpdate("DELETE FROM materials WHERE o_id = '" + id + "'");
                                } else if (base.equals("MatName")) {
                                    System.out.println("Which Materials do yuo want to delete type the Name:");
                                    String Name = STR.nextLine();
                                    MatDel.executeUpdate("DELETE FROM materials WHERE m_name = '" + Name + "'");
                                }

                            } else if (chTable.equals("Stack")) {
                                System.out.println("Type the name of stack that you want to delete:");
                                String StName = STR.nextLine();
                                StackDel.executeUpdate("DELETE FROM stack WHERE Name = '" + StName + "'");
                            }
                        } else if (DeUp.equals("Updation")) {
                            System.out.println("which table do you want to update(Owner,Materials,Stack)");
                            String UpChoice = STR.nextLine();
                            if (UpChoice.equals("Owner")) {
                                System.out.println("Which Column do you want to update(ID,Name,Address,Contact)");
                                String Col = STR.nextLine();
                                if (Col.equals("ID")) {
                                    System.out.println("Enter old id:");
                                    int O_id = INT.nextInt();
                                    System.out.println("Enter new id:");
                                    int N_id = INT.nextInt();
                                    PreparedStatement IDUP = con.prepareStatement("UPDATE owner SET O_ID = '" + N_id + "' WHERE O_ID = '" + O_id + "'");
                                    System.out.println("Updation occured successfully: " + IDUP.executeUpdate());
                                } else if (Col.equals("Name")) {
                                    System.out.println("Enter Old Name:");
                                    String O_Name = STR.nextLine();
                                    System.out.println("Enter New Name:");
                                    String N_Name = STR.nextLine();
                                    PreparedStatement NameUP = con.prepareStatement("UPDATE owner SET O_Name = '" + N_Name + "' WHERE O_Name = '" + O_Name + "'");
                                    System.out.println("Updation occured successfully: " + NameUP.executeUpdate());
                                } else if (Col.equals("Address")) {
                                    System.out.println("Enter Old Address:");
                                    String O_Address = STR.nextLine();
                                    System.out.println("Enter New Address:");
                                    String N_Address = STR.nextLine();
                                    PreparedStatement AddressUP = con.prepareStatement("UPDATE owner SET O_Address = '" + N_Address + "' WHERE O_Address = '" + O_Address + "'");
                                    System.out.println("Updation occured successfully: " + AddressUP.executeUpdate());
                                } else if (Col.equals("Contact")) {
                                    System.out.println("Enter Old Contact:");
                                    int O_Contact = INT.nextInt();
                                    System.out.println("Enter New Contact:");
                                    int N_Contact = INT.nextInt();
                                    PreparedStatement ContactUP = con.prepareStatement("UPDATE owner SET O_Contact = '" + N_Contact + "' WEHRE O_Contact = '" + O_Contact + "'");
                                    System.out.println("Updation occured successfully:" + ContactUP.executeUpdate());
                                }
                            } else if (UpChoice.equals("Materials")) {
                                System.out.println("Which column do you want to update(M_Name,M_Amount,M_Days,M_Price/Day,StackName,OwnerID)");
                                String MatCol = STR.nextLine();
                                if (MatCol.equals("M_Name")) {
                                    System.out.println("Enter Old Materials Name:");
                                    String O_Name = STR.nextLine();
                                    System.out.println("Enter New Materials Name:");
                                    String N_Name = STR.nextLine();
                                    PreparedStatement Name_UP = con.prepareStatement("UPDATE materials SET m_name = '" + N_Name + "' WHERE m_name = '" + O_Name + "'");
                                    System.out.println("Updation occured succussfully:" + Name_UP.executeUpdate());
                                } else if (MatCol.equals("M_Amount")) {
                                    System.out.println("Enter Old Materials Amount:");
                                    String O_Amount = STR.nextLine();
                                    System.out.println("Enter New Materials Amount:");
                                    String N_Amount = STR.nextLine();
                                    PreparedStatement AmountUP = con.prepareStatement("UPDATE materials SET amount = '" + N_Amount + "' WHERE amount = '" + O_Amount + "'");
                                    System.out.println("Updation occured successfully:" + AmountUP.executeUpdate());
                                } else if (MatCol.equals("M_Days")) {
                                    System.out.println("Enter Old number of days:");
                                    int O_days = INT.nextInt();
                                    System.out.println("Enter New number of days:");
                                    int N_days = INT.nextInt();
                                    PreparedStatement DaysUP = con.prepareStatement("UPDATE materials SET days = '" + N_days + "' WHERE days = '" + O_days + "'");
                                    System.out.println("Updation occured successfully:" + DaysUP.executeUpdate());
                                } else if (MatCol.equals("M_Price/Day")) {
                                    System.out.println("Enter Old Price/Day:");
                                    int O_price = INT.nextInt();
                                    System.out.println("Enter New Price/Day:");
                                    int N_price = INT.nextInt();
                                    PreparedStatement PriceUP = con.prepareStatement("UPDATE materials SET price_day = '" + N_price + "' WHERE price_day = '" + O_price + "'");
                                    System.out.println("Updation occured successfully:" + PriceUP.executeUpdate());
                                } else if (MatCol.equals("StackName")) {
                                    System.out.println("Enter Old Stack Name:");
                                    String O_Name = STR.nextLine();
                                    System.out.println("Enter New Stack Name:");
                                    String N_Name = STR.nextLine();
                                    PreparedStatement StackUP = con.prepareStatement("UPDATE materials SET s_name = '" + N_Name + "' WHERE s_name = '" + O_Name + "'");
                                    System.out.println("Updation occured successfully:" + StackUP.executeUpdate());
                                } else if (MatCol.equals("OwnerID")) {
                                    System.out.println("Enter Old ID of owner:");
                                    int O_id = INT.nextInt();
                                    System.out.println("Enter New ID of owner:");
                                    int N_id = INT.nextInt();
                                    PreparedStatement OwnerIDUP = con.prepareStatement("UPDATE materials SET o_id = '" + N_id + "' WHERE o_id = '" + O_id + "'");
                                    System.out.println("Updation occured successfully:" + OwnerIDUP.executeUpdate());
                                }
                            } else if (UpChoice.equals("Stack")) {
                                System.out.println("Which column do you want to update(Name,Address)");
                                String StackCh = STR.nextLine();
                                if (StackCh.equals("Name")) {
                                    System.out.println("Enter Old Name of Stack:");
                                    String O_Name = STR.nextLine();
                                    System.out.println("Enter New Name of Stack:");
                                    String N_Name = STR.nextLine();
                                    PreparedStatement NameUP = con.prepareStatement("UPDATE stack SET Name = '" + N_Name + "' WHERE Name = '" + O_Name + "'");
                                    System.out.println("Updation occured successfully:" + NameUP.executeUpdate());
                                } else if (StackCh.equals("Address")) {
                                    System.out.println("Enter Old Address of Stack:");
                                    String O_Name = STR.nextLine();
                                    System.out.println("Enter New Address of Stack:");
                                    String N_Name = STR.nextLine();
                                    PreparedStatement AddressUP = con.prepareStatement("UPDATE stack SET Address = '" + N_Name + "' WHERE Address = '" + O_Name + "'");
                                    System.out.println("Updation occured successfully:" + AddressUP.executeUpdate());
                                }
                            }
                        }
                        break;
                    case 4:
                        System.exit(choice);
                }

            }

        } catch (SQLException er) {
            System.out.println(er.toString());
        }

    }

}
